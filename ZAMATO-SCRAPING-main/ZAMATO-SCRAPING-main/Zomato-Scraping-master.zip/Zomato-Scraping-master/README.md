# Zomato-Scraping
In this I scrape details of Zomato-site
